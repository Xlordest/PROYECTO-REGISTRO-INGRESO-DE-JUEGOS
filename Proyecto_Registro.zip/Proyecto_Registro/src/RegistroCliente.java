/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author asanm
 */
public class RegistroCliente extends Cliente{
private int edad;
private String tiempoJugado;

    public RegistroCliente(int edad, String tiempoJugado, String Nombre, String Apellido, String Cedula, String Direccion, String Telefono) {
        super(Nombre, Apellido, Cedula, Direccion, Telefono);
        this.edad = edad;
        this.tiempoJugado = tiempoJugado;
    }
public boolean validarRegistro(){
    return super.validarCliente() && edad>=10 && edad<=100;
}
}
